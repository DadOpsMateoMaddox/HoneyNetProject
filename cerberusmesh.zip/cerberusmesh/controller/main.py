#!/usr/bin/env python3
"""
CerberusMesh Controller - Main orchestration service for honeypot management.

This module handles:
- EC2 instance lifecycle management
- SSH keypair creation and management
- Security group configuration
- Instance tagging and metadata logging
- Cowrie honeypot deployment
"""

import boto3
import json
import logging
import os
import time
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from pathlib import Path
import uuid
from dataclasses import dataclass

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('controller.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

@dataclass
class HoneypotConfig:
    """Configuration for honeypot instances."""
    instance_type: str = "t3.micro"
    ami_id: str = "ami-0c02fb55956c7d316"  # Amazon Linux 2 (update for your region)
    region: str = "us-east-1"
    vpc_id: Optional[str] = None
    subnet_id: Optional[str] = None
    key_name: str = "cerberusmesh-key"
    security_group_name: str = "cerberusmesh-sg"

class HoneypotController:
    """Main controller for managing honeypot infrastructure."""
    
    def __init__(self, config: Optional[HoneypotConfig] = None):
        """Initialize the controller with AWS clients and configuration."""
        self.config = config or HoneypotConfig()
        
        # Initialize AWS clients
        try:
            self.ec2_client = boto3.client('ec2', region_name=self.config.region)
            self.ec2_resource = boto3.resource('ec2', region_name=self.config.region)
            logger.info(f"Initialized AWS clients for region: {self.config.region}")
        except Exception as e:
            logger.error(f"Failed to initialize AWS clients: {e}")
            raise
        
        # Metadata storage
        self.metadata_file = Path("honeypot_metadata.json")
        self.metadata = self._load_metadata()
        
    def _load_metadata(self) -> Dict:
        """Load existing metadata or create new structure."""
        if self.metadata_file.exists():
            try:
                with open(self.metadata_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Could not load metadata: {e}")
        
        return {
            "instances": {},
            "keypairs": {},
            "security_groups": {},
            "created_at": datetime.now().isoformat()
        }
    
    def _save_metadata(self):
        """Save metadata to file."""
        try:
            with open(self.metadata_file, 'w') as f:
                json.dump(self.metadata, f, indent=2, default=str)
        except Exception as e:
            logger.error(f"Failed to save metadata: {e}")
    
    def create_keypair(self, key_name: Optional[str] = None) -> Tuple[str, str]:
        """Create SSH keypair for instance access."""
        key_name = key_name or self.config.key_name
        
        try:
            # Check if keypair already exists
            try:
                self.ec2_client.describe_key_pairs(KeyNames=[key_name])
                logger.info(f"Keypair {key_name} already exists")
                return key_name, "existing"
            except self.ec2_client.exceptions.ClientError:
                pass
            
            # Create new keypair
            response = self.ec2_client.create_key_pair(KeyName=key_name)
            private_key = response['KeyMaterial']
            
            # Save private key to file
            key_file = Path(f"{key_name}.pem")
            with open(key_file, 'w') as f:
                f.write(private_key)
            os.chmod(key_file, 0o600)
            
            # Update metadata
            self.metadata["keypairs"][key_name] = {
                "created_at": datetime.now().isoformat(),
                "key_file": str(key_file),
                "fingerprint": response['KeyFingerprint']
            }
            self._save_metadata()
            
            logger.info(f"Created keypair: {key_name}")
            return key_name, str(key_file)
            
        except Exception as e:
            logger.error(f"Failed to create keypair: {e}")
            raise
    
    def create_security_group(self, group_name: Optional[str] = None) -> str:
        """Create security group for honeypot instances."""
        group_name = group_name or self.config.security_group_name
        
        try:
            # Check if security group already exists
            try:
                response = self.ec2_client.describe_security_groups(
                    GroupNames=[group_name]
                )
                sg_id = response['SecurityGroups'][0]['GroupId']
                logger.info(f"Security group {group_name} already exists: {sg_id}")
                return sg_id
            except self.ec2_client.exceptions.ClientError:
                pass
            
            # Get default VPC if none specified
            vpc_id = self.config.vpc_id
            if not vpc_id:
                vpcs = self.ec2_client.describe_vpcs(
                    Filters=[{'Name': 'isDefault', 'Values': ['true']}]
                )
                if vpcs['Vpcs']:
                    vpc_id = vpcs['Vpcs'][0]['VpcId']
                else:
                    raise Exception("No default VPC found and none specified")
            
            # Create security group
            response = self.ec2_client.create_security_group(
                GroupName=group_name,
                Description="CerberusMesh Honeypot Security Group",
                VpcId=vpc_id
            )
            sg_id = response['GroupId']
            
            # Add inbound rules for honeypot services
            self.ec2_client.authorize_security_group_ingress(
                GroupId=sg_id,
                IpPermissions=[
                    {
                        'IpProtocol': 'tcp',
                        'FromPort': 22,
                        'ToPort': 22,
                        'IpRanges': [{'CidrIp': '0.0.0.0/0', 'Description': 'SSH Honeypot'}]
                    },
                    {
                        'IpProtocol': 'tcp',
                        'FromPort': 23,
                        'ToPort': 23,
                        'IpRanges': [{'CidrIp': '0.0.0.0/0', 'Description': 'Telnet Honeypot'}]
                    },
                    {
                        'IpProtocol': 'tcp',
                        'FromPort': 80,
                        'ToPort': 80,
                        'IpRanges': [{'CidrIp': '0.0.0.0/0', 'Description': 'HTTP Honeypot'}]
                    },
                    {
                        'IpProtocol': 'tcp',
                        'FromPort': 443,
                        'ToPort': 443,
                        'IpRanges': [{'CidrIp': '0.0.0.0/0', 'Description': 'HTTPS Honeypot'}]
                    }
                ]
            )
            
            # Update metadata
            self.metadata["security_groups"][group_name] = {
                "group_id": sg_id,
                "vpc_id": vpc_id,
                "created_at": datetime.now().isoformat()
            }
            self._save_metadata()
            
            logger.info(f"Created security group: {group_name} ({sg_id})")
            return sg_id
            
        except Exception as e:
            logger.error(f"Failed to create security group: {e}")
            raise
    
    def launch_honeypots(self, count: int = 1, tags: Optional[Dict] = None) -> List[Dict]:
        """Launch honeypot EC2 instances with Cowrie."""
        
        # Ensure prerequisites exist
        key_name, _ = self.create_keypair()
        security_group_id = self.create_security_group()
        
        # Default tags
        default_tags = {
            "Project": "CerberusMesh",
            "Type": "Honeypot",
            "CreatedBy": "CerberusMesh-Controller",
            "CreatedAt": datetime.now().isoformat()
        }
        if tags:
            default_tags.update(tags)
        
        # Cowrie installation user data script
        user_data = '''#!/bin/bash
yum update -y
yum install -y docker git python3 python3-pip

# Start Docker
systemctl start docker
systemctl enable docker
usermod -a -G docker ec2-user

# Install Cowrie
git clone https://github.com/cowrie/cowrie.git /opt/cowrie
cd /opt/cowrie
pip3 install -r requirements.txt

# Configure Cowrie
cp etc/cowrie.cfg.dist etc/cowrie.cfg
sed -i 's/hostname = svr04/hostname = honeypot/' etc/cowrie.cfg
sed -i 's/listen_endpoints = tcp:2222:interface=0.0.0.0/listen_endpoints = tcp:22:interface=0.0.0.0/' etc/cowrie.cfg

# Create cowrie user
useradd -r -s /bin/false cowrie
chown -R cowrie:cowrie /opt/cowrie

# Start Cowrie
sudo -u cowrie /opt/cowrie/bin/cowrie start

# Setup log forwarding (placeholder for future implementation)
echo "Cowrie honeypot deployed successfully" > /var/log/honeypot-deploy.log
'''
        
        launched_instances = []
        
        try:
            for i in range(count):
                instance_id = str(uuid.uuid4())[:8]
                
                # Create instance tags
                instance_tags = default_tags.copy()
                instance_tags.update({
                    "Name": f"cerberusmesh-honeypot-{instance_id}",
                    "InstanceId": instance_id
                })
                
                # Launch instance
                response = self.ec2_client.run_instances(
                    ImageId=self.config.ami_id,
                    MinCount=1,
                    MaxCount=1,
                    InstanceType=self.config.instance_type,
                    KeyName=key_name,
                    SecurityGroupIds=[security_group_id],
                    UserData=user_data,
                    TagSpecifications=[
                        {
                            'ResourceType': 'instance',
                            'Tags': [{'Key': k, 'Value': v} for k, v in instance_tags.items()]
                        }
                    ]
                )
                
                instance = response['Instances'][0]
                aws_instance_id = instance['InstanceId']
                
                # Store instance metadata
                instance_metadata = {
                    "aws_instance_id": aws_instance_id,
                    "instance_id": instance_id,
                    "instance_type": self.config.instance_type,
                    "ami_id": self.config.ami_id,
                    "key_name": key_name,
                    "security_group_id": security_group_id,
                    "state": instance['State']['Name'],
                    "launched_at": datetime.now().isoformat(),
                    "tags": instance_tags,
                    "private_ip": instance.get('PrivateIpAddress'),
                    "public_ip": instance.get('PublicIpAddress')
                }
                
                self.metadata["instances"][aws_instance_id] = instance_metadata
                launched_instances.append(instance_metadata)
                
                logger.info(f"Launched honeypot instance: {aws_instance_id} ({instance_id})")
            
            self._save_metadata()
            logger.info(f"Successfully launched {count} honeypot instances")
            return launched_instances
            
        except Exception as e:
            logger.error(f"Failed to launch instances: {e}")
            raise
    
    def terminate_instance(self, instance_id: str) -> bool:
        """Terminate a specific honeypot instance."""
        try:
            # Find instance in metadata
            instance_metadata = None
            for aws_id, metadata in self.metadata["instances"].items():
                if aws_id == instance_id or metadata.get("instance_id") == instance_id:
                    instance_metadata = metadata
                    aws_instance_id = aws_id
                    break
            
            if not instance_metadata:
                logger.error(f"Instance not found: {instance_id}")
                return False
            
            # Terminate instance
            self.ec2_client.terminate_instances(InstanceIds=[aws_instance_id])
            
            # Update metadata
            instance_metadata["state"] = "terminated"
            instance_metadata["terminated_at"] = datetime.now().isoformat()
            self._save_metadata()
            
            logger.info(f"Terminated instance: {aws_instance_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to terminate instance {instance_id}: {e}")
            return False
    
    def list_instances(self) -> List[Dict]:
        """List all managed honeypot instances."""
        try:
            # Get current AWS instance states
            if not self.metadata["instances"]:
                return []
            
            aws_instance_ids = list(self.metadata["instances"].keys())
            response = self.ec2_client.describe_instances(InstanceIds=aws_instance_ids)
            
            # Update metadata with current states
            current_instances = {}
            for reservation in response['Reservations']:
                for instance in reservation['Instances']:
                    aws_id = instance['InstanceId']
                    if aws_id in self.metadata["instances"]:
                        metadata = self.metadata["instances"][aws_id].copy()
                        metadata.update({
                            "state": instance['State']['Name'],
                            "public_ip": instance.get('PublicIpAddress'),
                            "private_ip": instance.get('PrivateIpAddress'),
                            "launch_time": instance.get('LaunchTime')
                        })
                        current_instances[aws_id] = metadata
            
            return list(current_instances.values())
            
        except Exception as e:
            logger.error(f"Failed to list instances: {e}")
            return []
    
    def cleanup_all(self) -> Dict[str, int]:
        """Terminate all managed instances and clean up resources."""
        results = {"terminated": 0, "errors": 0}
        
        for aws_instance_id in list(self.metadata["instances"].keys()):
            if self.terminate_instance(aws_instance_id):
                results["terminated"] += 1
            else:
                results["errors"] += 1
        
        logger.info(f"Cleanup completed: {results}")
        return results

def main():
    """CLI interface for the controller."""
    import argparse
    
    parser = argparse.ArgumentParser(description="CerberusMesh Honeypot Controller")
    parser.add_argument("action", choices=["launch", "list", "terminate", "cleanup"], 
                       help="Action to perform")
    parser.add_argument("--count", type=int, default=1, 
                       help="Number of instances to launch")
    parser.add_argument("--instance-id", 
                       help="Instance ID to terminate")
    parser.add_argument("--region", default="us-east-1",
                       help="AWS region")
    parser.add_argument("--instance-type", default="t3.micro",
                       help="EC2 instance type")
    
    args = parser.parse_args()
    
    # Initialize controller
    config = HoneypotConfig(
        region=args.region,
        instance_type=args.instance_type
    )
    controller = HoneypotController(config)
    
    # Execute action
    if args.action == "launch":
        instances = controller.launch_honeypots(args.count)
        print(f"Launched {len(instances)} instances:")
        for instance in instances:
            print(f"  - {instance['aws_instance_id']} ({instance['instance_id']})")
    
    elif args.action == "list":
        instances = controller.list_instances()
        print(f"Found {len(instances)} instances:")
        for instance in instances:
            print(f"  - {instance['aws_instance_id']} ({instance['instance_id']}) - {instance['state']}")
    
    elif args.action == "terminate":
        if not args.instance_id:
            print("Error: --instance-id required for terminate action")
            return
        if controller.terminate_instance(args.instance_id):
            print(f"Terminated instance: {args.instance_id}")
        else:
            print(f"Failed to terminate instance: {args.instance_id}")
    
    elif args.action == "cleanup":
        results = controller.cleanup_all()
        print(f"Cleanup results: {results}")

if __name__ == "__main__":
    main()
