# CerberusMesh GPT CVSS Module
